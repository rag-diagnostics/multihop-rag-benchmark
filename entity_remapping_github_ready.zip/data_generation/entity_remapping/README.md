# Entity remapping (ECIR paper §3.2)

This directory contains the **unaltered Python source** of the entity-transformation stage from the first code cell of the author's archived `dataset_creation.ipynb`, plus a one-cell notebook copy. The Python statements, replacement lists, transformations, randomisation policy, input/output names, and probability are unchanged. The original notebook's other cells (QA generation, experimental processing, and outputs) are **not** part of this stage.

## What it does

- Shuffles fixed pools of replacement countries/adjectives and cities and creates a run-level mapping.
- Replaces the configured named entities and regions, transforms season names, and replaces recognised four-digit numbers with generated AD/BC dates.
- Uses WordNet to optionally substitute nouns and verbs with probability **0.1**.
- Applies the transformation to the Excel column **`Summary`**, retaining other workbook columns.

**This is a historical implementation, not a redesigned or corrected algorithm.** In particular, there is no fixed random seed and the script replaces eligible year occurrences sequentially, so repeated original dates are not guaranteed to receive the same replacement. Running it again will generally produce different text. No claims of perfect relational preservation or exact reconstruction are made here.

## Prerequisites

Python 3.10+ is suggested. Install dependencies from inside this directory:

```bash
python -m pip install -r requirements.txt
python -m spacy download en_core_web_sm
python -m nltk.downloader wordnet
```

The spaCy language model and NLTK WordNet corpus are external resources and are not bundled in the repository.

## Input and output (historical names retained)

| File/column | Role |
|---|---|
| `final_dataset.xlsx` | Required source workbook; **not included** in this code-only package |
| `Summary` | Required column containing original narrative text |
| `0modified_final_dataset_004.xlsx` | Output workbook with transformed `Summary` values |

Put `final_dataset.xlsx` in your current working directory and run:

```bash
python remap_entities.py
```

You can alternatively open `remap_entities.ipynb` and run its single cell with the same working directory. Do not execute **both** if you intend to compare their outputs: the unseeded random remapping will vary across runs.

Both workbooks are ignored by this directory's `.gitignore`. Do not commit data containing unpublished or restricted material.

## Reproducibility and limitations

- `remap_entities.py` exactly matches the source of cell 0 in the archived notebook; see `SOURCE_PROVENANCE.md`.
- The archive did **not** contain the required `final_dataset.xlsx` under that name, so an end-to-end transformation has not been verified here.
- The notebook's separate QA-generation code is intentionally excluded. That will be a later, distinct GitHub upload.
- This stage uses **no hosted LLM API and requires no API key**.
- The module was syntax-checked, but an actual end-to-end run was not performed in the packaging environment because the input workbook and required model/corpus assets were unavailable.

## Relation to the paper

This covers the **implementation of Section 3.2, Randomised Entity Transformation** only. It does not demonstrate source-to-narrative conversion (§3.1), QA generation (§3.3), or subsequent benchmark construction. The researcher must verify that the source workbook and algorithm correspond to the final manuscript version.
